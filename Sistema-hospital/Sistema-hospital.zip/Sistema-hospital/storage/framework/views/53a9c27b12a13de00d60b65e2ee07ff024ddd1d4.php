<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Registro de Paciente</div>

                <div class="panel-body">
                   
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('pacientes.store')); ?>">
                        <?php echo e(csrf_field()); ?>


                           <div class="form-group<?php echo e($errors->has('idPersona') ? ' has-error' : ''); ?>">
                            <label for="idPersona" class="col-md-4 control-label">Identificación</label>

                            <div class="col-md-6">
                                <input id="idPersona" type="text" class="form-control" name="idPersona" value="<?php echo e(old('idPersona')); ?>" required autofocus>

                                <?php if($errors->has('idPersona')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('idPersona')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('Persona_Nombre') ? ' has-error' : ''); ?>">
                            <label for="Persona_Nombre" class="col-md-4 control-label">Nombre de la persona</label>

                            <div class="col-md-6">
                                <input id="Persona_Nombre" type="text" class="form-control" name="Persona_Nombre" value="<?php echo e(old('Persona_Nombre')); ?>" disabled>

                                <?php if($errors->has('Persona_Nombre')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Persona_Nombre')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        
                         <div class="form-group<?php echo e($errors->has('Persona_Apellido') ? ' has-error' : ''); ?>">
                            <label for="Persona_Apellido" class="col-md-4 control-label">Apellido de la persona</label>

                            <div class="col-md-6">
                                <input id="Persona_Apellido" type="text" class="form-control" name="Persona_Apellido" value="<?php echo e(old('Persona_Apellido')); ?>" disabled>

                                <?php if($errors->has('Persona_Apellido')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Persona_Apellido')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        
                        <div class="form-group<?php echo e($errors->has('Condicion_Llegada') ? ' has-error' : ''); ?>">
                            <label for="Condicion_Llegada" class="col-md-4 control-label">Condición</label>

                            <div class="col-md-6">
                                <input id="Condicion_Llegada" type="textarea" class="form-control" name="Condicion_Llegada" value="<?php echo e(old('Condicion_Llegada')); ?>" required autofocus>

                                <?php if($errors->has('Condicion_Llegada')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Condicion_Llegada')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div> 
                             
                        </div>

                        
                        
                        <div class="form-group<?php echo e($errors->has('ubicacion') ? ' has-error' : ''); ?>">
                            <label for="ubicacion" class="col-md-4 control-label">Ubicación</label>

                            <div class="col-md-6">
                                <input id="ubicacion" type="textarea" class="form-control" name="ubicacion" value="<?php echo e(old('ubicacion')); ?>" required autofocus>

                                <?php if($errors->has('ubicacion')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('ubicacion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div> 
                             
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Registrar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>