<?php $__env->startSection('titulo',"Pacientes"); ?>

<?php $__env->startSection('navegacion'); ?>
    <a href="<?php echo e(route('pacientes.create')); ?>" class="navbar-brand">Agregar Paciente</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <link rel="stylesheet" href="http://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="h2 text-center panel-heading text-primary">Listado de pacientes</div>

          <h2>hay <?php echo e($pacientes->count()); ?> pacientes</h2>

                    <div class="table-responsive" id="txtHint">

                         <form class="navbar-form navbar-left " role="search" action="<?php echo e(url('personas/home')); ?>" method="GET">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Nombre del paciente" id="NombrePaciente" name="NombrePaciente">
                            </div>
                            <button type="submit" class="btn btn-default">Buscar</button>
                        </form>

                        
                        <table class="table table-condensed table-striped table-bordered table-hover" id="tabla">
                            <thead>
                                <th>Número de Identidad</th>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Condición</th>
                                <th>Ubicación</th>
                                <th colspan="2">Acciones</th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($Paciente->idPersona); ?></td>
                                    <td><?php echo e($Paciente->Persona_Nombre); ?></td>
                                    <td><?php echo e($Paciente->Persona_Apellido); ?></td>
                                    <td><?php echo e($Paciente->condicion_llegada); ?></td>
                                    <td><?php echo e($Paciente->ubicacion); ?></td>

                                    <td><a href="<?php echo e(route('pacientes.edit', $Paciente->idPaciente)); ?>"><button type="button" class="btn btn-info">Editar</button></a></td>
                                    <td>
                                        
                                        <?php echo e(Form::open(array('url' => 'pacientes/' . $Paciente->idPaciente, 'class' => 'pull-right'))); ?>

                                        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                        <?php echo e(Form::submit('Eliminar', array('class' => 'btn btn-warning'))); ?>

                                        <?php echo e(Form::close()); ?>

                                        
                                    </td>

                                   

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo $pacientes->render(); ?>

                </div>
            </div>
        </div>
    </div>

    

    <script src="http://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    
    
    <!--<script>
    $(document).ready(function(){
       $("#search").keyup(function(){
           var str=  $("#search").val();
           if(str == "") {
                   $( "#txtHint" ).html("<b>Buscando paciente...</b>"); 
           }else {
                   $.get( "<?php echo e(url('pacientes/buscarNombre')); ?>"+str, function( data ) {
                       $( "#txtHint" ).html( data );  
                });
           }
       });  
    }); 
    </script> -->



<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>