<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Registro de Empleado</div>

                <div class="panel-body">
                   
                    <form class="form-horizontal" method="POST" action="<?php echo e(url('empleados/crear')); ?>">
                        <?php echo e(csrf_field()); ?>


                           <div class="form-group<?php echo e($errors->has('idPersona') ? ' has-error' : ''); ?>">
                            <label for="idPersona" class="col-md-4 control-label">Identificación</label>

                            <div class="col-md-6">
                                <input id="idPersona" type="text" class="form-control" name="idPersona" value="<?php echo e(old('idPersona')); ?>" required autofocus>

                                <?php if($errors->has('idPersona')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('idPersona')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('Persona_Nombre') ? ' has-error' : ''); ?>">
                            <label for="Persona_Nombre" class="col-md-4 control-label">Nombre de la persona</label>

                            <div class="col-md-6">
                                <input id="Persona_Nombre" type="text" class="form-control" name="Persona_Nombre" value="<?php echo e(old('Persona_Nombre')); ?>" disabled>

                                <?php if($errors->has('Persona_Nombre')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Persona_Nombre')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        
                         <div class="form-group<?php echo e($errors->has('Persona_Apellido') ? ' has-error' : ''); ?>">
                            <label for="Persona_Apellido" class="col-md-4 control-label">Apellido de la persona</label>

                            <div class="col-md-6">
                                <input id="Persona_Apellido" type="text" class="form-control" name="Persona_Apellido" value="<?php echo e(old('Persona_Apellido')); ?>" disabled>

                                <?php if($errors->has('Persona_Apellido')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Persona_Apellido')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        
                        <div class="form-group<?php echo e($errors->has('Empleado_cargo') ? ' has-error' : ''); ?>">
                            <label for="Empleado_cargo" class="col-md-4 control-label">Cargo</label>

                            <div class="col-md-6">
                                <input id="Empleado_cargo" type="textarea" class="form-control" name="Empleado_cargo" value="<?php echo e(old('Empleado_cargo')); ?>" required autofocus>

                                <?php if($errors->has('Empleado_cargo')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Empleado_cargo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div> 
                             
                        </div>


                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Registrar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>